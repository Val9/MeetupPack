var label1 = Titanium.UI.createLabel({
	color:'#999',
	text:'I am the photo window',
	font:{fontSize:20,fontFamily:'Helvetica Neue'},
	textAlign:'center',
	width:'auto'
});

Ti.UI.currentWindow.add(label1);