var win = Ti.UI.currentWindow;

var photoOptions = Ti.UI.createView({
  top:10,
  height:'auto',
  width:'auto',
  layout:'vertical'
});

var galleryButton = Ti.UI.createButton({
  title:'Choose A Photo',
  top:10,
  height:40,
  width:200
});

var cameraButton = Ti.UI.createButton({
  title:'Take A Photo',
  top:10,
  height:40,
  width:200
});

var preview = Ti.UI.createImageView({
  top:10,
  height:150,
  width:150
});

var postButton = Ti.UI.createButton({
  title:'Oh Snap!',
  bottom:10,
  height:70,
  width:100
});

photoOptions.add(galleryButton);
photoOptions.add(cameraButton);
photoOptions.add(preview);

win.add(photoOptions);
win.add(postButton);

function handleImageEvent(event) {
  preview.image = event.media;
}

galleryButton.addEventListener("click", function(e) {
  Titanium.Media.openPhotoGallery({
  	success:handleImageEvent
  });
});

cameraButton.addEventListener("click", function(e) {
  Titanium.Media.showCamera({
  	success:handleImageEvent //you would also specify an error callback for when no camera is present
  });
});