Titanium.UI.setBackgroundColor('#000');

//Main Tab Group
var tabGroup = Titanium.UI.createTabGroup();

//Photo Selection Window
var photosWindow = Titanium.UI.createWindow({  
  url:'photos.js',
  title:'Photos',
  backgroundColor:'#fff'
});
var photosTab = Titanium.UI.createTab({  
  icon:'43-film-roll.png',
  title:'Photos',
  window:photosWindow
});

//Configuration Window
var configWindow = Titanium.UI.createWindow({  
  url:'config.js',
  title:'Configuration',
  backgroundColor:'#fff'
});
var configTab = Titanium.UI.createTab({  
  icon:'19-gear.png',
  title:'Configuration',
  window:configWindow
});

//Add tabs and open tab group
tabGroup.addTab(photosTab);
tabGroup.addTab(configTab);
tabGroup.open();
