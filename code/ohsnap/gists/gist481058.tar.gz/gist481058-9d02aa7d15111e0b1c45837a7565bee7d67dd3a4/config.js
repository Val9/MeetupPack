function header(text) {
  return Ti.UI.createLabel({
    top:10,
    text:text,
    height:'auto',
    width:'auto',
    font:{
      fontWeight:'bold',
      fontSize:20
    }
  });
}

var configContainer = Ti.UI.createView({
  top:10,
  height:'auto',
  width:'auto',
  layout:'vertical'
});

configContainer.add(header('Twitter Username'));

var unField = Titanium.UI.createTextField({
	value:'kevinwhinnery',
	height:35,
	top:10,
	width:250,
	hintText:'Twitter Username',
	keyboardType:Titanium.UI.KEYBOARD_DEFAULT,
	returnKeyType:Titanium.UI.RETURNKEY_DEFAULT,
	borderStyle:Titanium.UI.INPUT_BORDERSTYLE_ROUNDED,
	autocorrect:false
});
configContainer.add(unField);

configContainer.add(header('Twitter Password'));

var pwField = Titanium.UI.createTextField({
	color:'#787878',
	value:'secret',
	height:35,
	top:10,
	width:250,
	hintText:'Twitter Password',
	keyboardType:Titanium.UI.KEYBOARD_DEFAULT,
	returnKeyType:Titanium.UI.RETURNKEY_DEFAULT,
	borderStyle:Titanium.UI.INPUT_BORDERSTYLE_ROUNDED,
	autocorrect:false,
	passwordMask:true
});
configContainer.add(pwField);

var saveButton = Ti.UI.createButton({
  top:10,
  title:'Save',
  height:40,
  width:100
});
configContainer.add(saveButton);

Ti.UI.currentWindow.add(configContainer);